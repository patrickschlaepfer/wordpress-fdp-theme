<?php get_header(); ?>

    <div id="container_content_context">
        <div id="container_content_context_padding">
            <div id="container_content">
                <div id="container_content_padding">
                    <h1>Fehler!</h1>
                    <p>&nbsp;</p>
                    <h2>Die gew&uuml;schte Seite ist nicht verf&uuml;gbar.<br />
                </div>
            </div>
        </div>
    </div><!-- main -->

<?php get_footer(); ?>
