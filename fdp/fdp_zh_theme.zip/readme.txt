Die folgenden Plugins werden benoetigt:
* AJAX Thumbnail Rebuild
* Bannerspace
* Blog in Blog
* Contact Form 7
* FaceBook Share
* Query Post
* Really Simple CAPTCHA
* Relevanssi
* Sitemap
* WP Facebook Like
* WPtouch
* YouTube SimpleGallery
