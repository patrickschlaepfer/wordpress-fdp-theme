  <hr class="grid_12">
  <div class="grid_4 secondary"> 
    <a href="/?page_id=11">Kontakt</a> | 
    <a href="/?page_id=66" class="footerLeftLink">Sitemap</a> | 
    <a href="/?page_id=58" class="footerLeftLink">Impressum</a>
  </div>
  <div class="grid_4 secondary aligncenter">
    Theme by <a href="http://www.schlaepfer.com" target="_blank">schlaepfer.com</a>
  </div>
  <div class="grid_4 secondary alignright">
      powered by <a href="http://wordpress.org/" target="_blank">wordpress</a>
    </div>
  </div>
</div><!-- wrapper -->

<?php wp_footer(); ?>

<!-- Statistik/Analyse-Tool einbauen -->

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-4398388-14']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

</body>
</html>
