<ul id="sidebar">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
<!-- Standard-Sidebar, wenn keine Widgets vorhanden sind -->
<?php endif; ?>
<!-- zus�tzliche statische Sidebar-Elemente -->

</ul>

